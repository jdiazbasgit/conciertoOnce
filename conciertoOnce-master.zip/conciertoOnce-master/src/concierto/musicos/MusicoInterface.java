/**
 * 
 */
package concierto.musicos;

/**
 * @author fjdia
 *interface de los musicos
 */
public interface MusicoInterface {

	public void tocar();
}
