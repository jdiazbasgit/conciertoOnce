/**
 * 
 */
package concierto.instrumentos;

import concierto.beans.InstrumentoBean;

/**
 * @author profe
 *Interface que genera clases de instrumentos
 */
public interface InstrumentoInterface {

	public String sonar();
}
